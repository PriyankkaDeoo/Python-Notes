# Nested List
a = [[10, 20, 30], [40, 50, 60]]
print("A:",a)
print("a[0]:",a[0])
print("a[1]:",a[1])
print()
print(a[0][0])
print(a[0][1])
print(a[0][2])
print(a[1][0])
print(a[1][1])
print(a[1][2])



