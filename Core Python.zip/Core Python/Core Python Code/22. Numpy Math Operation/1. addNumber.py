from numpy import *
a = array([101, 102, 103, 104, 105])
a = a + 5

for el in a:
	print(el)
print()