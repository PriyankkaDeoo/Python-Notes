# If elif Statement
a = 10
b = 20
if a > b:
	print("a is greater than b")
elif a == b:
	print("a and b are equal")
elif a < b:
	print("a is less than b")

# If elif with User Input
a = int(input("Enter Value of A: "))
b = int(input("Enter Value of B: "))
if a > b:
	print("a is greater than b")
elif a == b:
	print("a and b are equal")
elif a < b:
	print("a is less than b")