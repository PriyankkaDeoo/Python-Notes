#insert() Method
a = [10, 20, 30, 10, 90, 'Geekyshows']

print("Before:",a)

a.insert(3, 'Subscribe')

print("After:",a)

for element in a:
	print (element)