a = [10, 20, 30]
b = [1, 2, 3]
c = [101, 102, 103]

print(a)
print(b)
print(c)

result = a + b + c

print(result)