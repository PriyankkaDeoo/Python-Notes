from math import *

print(floor(4.5))
print(ceil(4.5))
print(sqrt(49))
print(factorial(5))
print(pow(5, 2))