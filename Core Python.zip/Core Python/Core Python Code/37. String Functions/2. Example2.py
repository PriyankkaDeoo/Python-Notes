print("****** isupper Function ******")
name = "GEEKYSHOWS"
str1 = name.isupper()
print(name)
print(str1)

print("****** islower Function ******")
name = "geekyshows"
str1 = name.islower()
print(name)
print(str1)

print("****** istitle Function ******")
name = "Hello Geekyshows How Are You"
str1 = name.istitle()
print(name)
print(str1)