print("****** isdigit Function ******")
name = "342343"
str1 = name.isdigit()
print(name)
print(str1)

print("****** isalpha Function ******")
name = "GEEKyshows"
str1 = name.isalpha()
print(name)
print(str1)

print("****** isalnum Function ******")
name = "GEEKyshows2343"
str1 = name.isalnum()
print(name)
print(str1)