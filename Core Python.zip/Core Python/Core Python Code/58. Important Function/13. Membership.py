# Membership 
a = "GeekyShows"
b = [10, 20, 30, 5]
c = (10, 20, 30, 6, 40)
d = {10, 20, 30, 9,  40, 50}
e = {101:'Rahul', 102:'Raj', 103:'Sonam', 2:'Jay'}
print("String:")
print('G' in a)
print('G' not in a)
print()
print("List:")
print(10 in b)
print(10 not in b)
print()
print("Tuple:")
print(10 in c)
print(10 not in c)
print()
print("Set:")
print(10 in d)
print(10 not in d)
print()
print("Dictionary:")
print(101 in e)
print(101 not in e)
