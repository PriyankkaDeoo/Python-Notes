# max() Function
b = [10, 20, 30, 5]
c = (10, 20, 30, 6, 40)
d = {10, 20, 30, 9,  40, 50}
e = {101:'Rahul', 102:'Raj', 103:'Sonam', 2:'Jay'}
f = [[10, 20], [30, 40], [60, 70], [2, 4]]
g = [(101, 'Rahul'), (102, 'Raj'), (2, 'Jay'), (103, 'Sonam')]
print(max(b))
print(max(c))
print(max(d))
print(max(e))
print(max(f))
print(max(g))