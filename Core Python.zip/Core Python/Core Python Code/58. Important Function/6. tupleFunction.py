# tuple() Function
a = [10,20,30]
print(a)
print(type(a))
new_a = tuple(a)
print(new_a)
print(type(new_a))
print()

b = {10,20,30}
print(b)
print(type(b))
new_b = tuple(b)
print(new_b)
print(type(new_b))
print()

c = "GeekyShows"
print(c)
print(type(c))
new_c = tuple(c)
print(new_c)
print(type(new_c))
print()

d = {101:'Rahul', 102:'Raj', 103:'Sonam'}
print(d)
print(type(d))
new_d = tuple(d)
print(new_d)
print(type(new_d))
print()
