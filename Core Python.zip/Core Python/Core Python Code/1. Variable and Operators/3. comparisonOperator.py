#print(5<2)
a = 5
b = 2
value = a < b
print(value)

#print(5>2)
a = 5
b = 2
value = a > b
print(value)

#print(5<=2)
a = 5
b = 2
value = a <= b
print(value)

#print(5>=2)
a = 5
b = 2
value = a >= b
print(value)

#print(5==2)
a = 5
b = 2
value = a == b
print(value)

#print(5!=2)
a = 5
b = 2
value = a != b
print(value)
