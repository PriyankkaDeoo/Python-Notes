# Declaring and initializing Variable
# Individual
a = 10
b = 10.23
c = "GeekyShows"
d = 'GeekyShows'

# Multiple
e, f, g, h = 10, 10.23, "GeekyShows", 'GeekyShows'

# Multiple with same value
i = j = k = l = m = n = True

print(a)
print(b)
print(c)
print(d)
print(e)
print(f)
print(g)
print(h)
print(i)
print(j)
print(n)
print("$"*20)

