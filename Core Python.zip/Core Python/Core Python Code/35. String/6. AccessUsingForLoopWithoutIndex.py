str1 = "GeekyShows"
for c in str1:
	print(c)

