str1 = "GeekyShows"
n = len(str1)
print(n)

