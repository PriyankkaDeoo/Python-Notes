str1 = "GeekyShows"
str2 = "GeekyShows"
str3 = "Python"
str4 = str3
print("str1=", str1, id(str1))
print("str2=", str2, id(str2))
print("str3=", str3, id(str3))
print("str4=", str4, id(str4))