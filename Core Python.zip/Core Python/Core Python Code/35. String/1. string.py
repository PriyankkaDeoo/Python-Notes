str1 = 'GeekyShows'
str2 = "GeekyShows"
str3 = '''Hello Guys
Please Subscribe
GeekyShows'''
str4 = """Hello Guys
Please Subscribe
GeekyShows"""
str5 = 'Hello "Geeky Shows" How are you'
str6 = "Hello 'Geeky Shows' How are you"
str7 = "Hello \nHow are you"
str8 = r"Hello \nHow are you"

print(str1)
print("**************************")
print(str2)
print("**************************")
print(str3)
print("**************************")
print(str4)
print("**************************")
print(str5)
print("**************************")
print(str6)
print("**************************")
print(str7)
print("**************************")
print(str8)
