print("Geeky" + "Shows")

str1 = "Geeky "
str2 = "Shows"
str3 = str1 + str2
print(str3)

