(lambda x : print(x + 1))(5)
(lambda x, y : print(x + y))(5, 2)