# For Loop
st = "GeekyShows"
for ch in st:
	print(ch)

print("Rest of the Code")