a = [True, False, False, True, False, True, True]

result = list(filter(None,a))
print(result)
print(type(result))




