a = 20
assert a <= 10, 'Invalid Number'