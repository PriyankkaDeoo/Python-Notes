from logging import *
basicConfig(filename="logfile.log")
warning("This is Warning")
error("This is Error")
critical("This is Critical")