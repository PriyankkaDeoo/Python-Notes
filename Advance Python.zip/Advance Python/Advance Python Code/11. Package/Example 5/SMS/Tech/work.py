# Tech Package --> work Module
#import sys
#sys.path.append('C:/Users/RK/Desktop/SMS/User')
#import request
from User import request
def tech_work():
	print("Tech Package --> work Module")
	print("tech_work Function")
	print()
	
request.user_request()