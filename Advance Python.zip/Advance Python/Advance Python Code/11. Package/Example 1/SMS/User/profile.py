# User Package --> profile Module

def user_profile():
	print("User Package --> profile Module")
	print("user_profile Function")
	print()