# Admin Package --> service Module

def admin_service():
	print("Admin Package --> service Module")
	print("admin_service Function")
	print()