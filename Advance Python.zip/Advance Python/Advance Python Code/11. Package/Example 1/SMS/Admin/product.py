# Admin Package --> product Module

def admin_product():
	print("Admin Package --> product Module")
	print("admin_product Function")
	print()