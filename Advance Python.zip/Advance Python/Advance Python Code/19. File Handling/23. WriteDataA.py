# Writing Data with a mode
f = open('student.txt', mode='a')
f.write('Hello\n')
f.write('GeekyShows\n')
f.write('How are you')
f.close()
print('Success')