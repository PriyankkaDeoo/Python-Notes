with open('student.txt') as f:
	data = f.read()
	print(data)
	print('File Closed:',f.closed)
print('File Closed:',f.closed)

