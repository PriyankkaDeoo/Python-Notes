import os
os.rename('mydir', 'yourdir')