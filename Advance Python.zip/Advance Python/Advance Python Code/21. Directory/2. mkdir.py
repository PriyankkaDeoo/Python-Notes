import os
os.mkdir('mydir')
os.mkdir('mydir/mychilddir')