# Constructor
class Mobile:
	# Constructor without parameter
	def __init__(self):
		self.model = 'RealMe X'
		
	def show_model(self):
		print("Model:", self.model)


realme = Mobile()
realme.show_model()
