# Example 2
class Myclass:
	def show(self):
		print("I am a Method")

x = Myclass()
x.show()

