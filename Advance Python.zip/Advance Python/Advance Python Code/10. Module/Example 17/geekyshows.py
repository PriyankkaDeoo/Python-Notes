# geekyshows.py <--- Main Module

from first import Myclass, Myschool			# Importing first Module
c = Myclass()			# Creating Myclass Object - first Module
c.name()

s = Myschool()		# Creating Myschool Object - first Module
s.show()

from second import Myclass					# Importing second Module
s = Myclass()		# Creating Myschool Object - second Module
s.disp()
