# geekyshows.py <--- Main Module

import first			# Importing first Module
import second					# Importing second Module

c = first.Myclass()			# Creating Myclass Object - first Module
c.name()

s = first.Myschool()		# Creating Myschool Object - first Module
s.show()

s = second.Myclass()		# Creating Myschool Object - second Module
s.disp()
