#second.py  <--- second Module
class Mycollege:
	def disp(self):
		print("Disp Method from Second Module")
	