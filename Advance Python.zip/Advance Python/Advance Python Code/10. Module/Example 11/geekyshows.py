# geekyshows.py <--- Main Module

import first			# Importing first Module

c = first.Myclass()		# Creating Myclass Object
c.name()

s = first.Myschool()	# Creating Myschool Object
s.show()

