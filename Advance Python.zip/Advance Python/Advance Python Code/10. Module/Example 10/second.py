#second.py  <--- second Module
a = 'Second Module'

def name():
	print("Name Function From Second Module")
	