# geekyshows.py <--- Main Module

from cal import *					# Importing Cal Module

print("cal Module's variable:", a)	# Accessing Cal Module's Variable

name()								# Accessing Cal Module's Function

a = add(10,20)						# Accessing Cal Module's Function
print(a)

b = sub(20, 10)						# Accessing Cal Module's Function
print(b)
